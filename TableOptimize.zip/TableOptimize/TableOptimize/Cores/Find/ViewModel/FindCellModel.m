//
//  FindCellModel.m
//  TableOptimize
//
//  Created by Yuan on 16/3/18.
//  Copyright © 2016年 Ace. All rights reserved.
//

#import "FindCellModel.h"
#import "FindCell.h"
@implementation FindCellModel
-(NSInteger) findnumberOfRowsInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return 2;
            break;
            
        case 1:
            return 1;
            break;
            
        case 2:
            return 1;
            break;
            
        default:
            break;
    }
    return 0;
}

-(UITableViewCell *) findtableView:(UITableView *)tableView findcellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case 0:
        {
            switch (indexPath.row) {
                case 0:
                {
                    FindCell *voteCell = [tableView dequeueReusableCellWithIdentifier:@"VoteCell"];
                    if (!voteCell) {
                        voteCell = [[FindCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"VoteCell"];
                    }
                    voteCell.logoImageView.image = [UIImage imageNamed:@"find_vote"];
                    voteCell.titleLabel.text = @"投票";
                    return voteCell;
                }
                    break;
                    
                case 1:
                {
                    FindCell *activityCell = [tableView dequeueReusableCellWithIdentifier:@"ActivityCell"];
                    if (!activityCell) {
                        activityCell = [[FindCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ActivityCell"];
                    }
                    activityCell.logoImageView.image = [UIImage imageNamed:@"find_activity"];
                    activityCell.titleLabel.text = @"活动";
                    return activityCell;
                }
                    break;
                    
                default:
                    break;
            }
        }
            break;
            
        case 1:
        {
            FindCell *featuresCell = [tableView dequeueReusableCellWithIdentifier:@"FeaturesCell"];
            if (!featuresCell) {
                featuresCell = [[FindCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"FeaturesCell"];
            }
            featuresCell.logoImageView.image = [UIImage imageNamed:@"find_features"];
            featuresCell.titleLabel.text = @"专题";
            return featuresCell;
        }
            break;
            
        case 2:
        {
            FindCell *gameCell = [tableView dequeueReusableCellWithIdentifier:@"GameCell"];
            if (!gameCell) {
                gameCell = [[FindCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"GameCell"];
            }
            gameCell.logoImageView.image = [UIImage imageNamed:@"find_game"];
            gameCell.titleLabel.text = @"游戏中心";
            return gameCell;
        }
            break;
            
        default:
            break;
    }
    return nil;
    
}
@end
