//
//  FindCellModel.h
//  TableOptimize
//
//  Created by Yuan on 16/3/18.
//  Copyright © 2016年 Ace. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface FindCellModel : NSObject

-(NSInteger) findnumberOfRowsInSection:(NSInteger)section;

-(UITableViewCell *)findtableView:(UITableView *)tableView findcellForRowAtIndexPath:(NSIndexPath *)indexPath;

@end
