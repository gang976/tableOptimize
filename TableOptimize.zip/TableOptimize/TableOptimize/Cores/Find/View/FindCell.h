//
//  FindCell.h
//  TableOptimize
//
//  Created by Yuan on 16/3/18.
//  Copyright © 2016年 Ace. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FindCell : UITableViewCell

@property (strong,nonatomic) UIImageView *logoImageView;
@property (strong,nonatomic) UILabel *titleLabel;
@property (strong,nonatomic) UIImageView *nextImageView;
@end
