//
//  FindCell.m
//  TableOptimize
//
//  Created by Yuan on 16/3/18.
//  Copyright © 2016年 Ace. All rights reserved.
//

#import "FindCell.h"

@implementation FindCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        [self setUpCellUI];
    }
    return self;
}

-(void) setUpCellUI
{
    CGFloat Width = [UIScreen mainScreen].bounds.size.width;
    
    _logoImageView = [[UIImageView alloc]initWithFrame:CGRectMake(20, 13, 26, 26)];
    [self.contentView addSubview:_logoImageView];
    
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(66, 16, 110, 20)];
    [_titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:15]];
    _titleLabel.textColor = [UIColor colorWithRed:90.0 / 255.0 green:90.0 / 255.0 blue:90.0 / 255.0 alpha:1.0];
    [self.contentView addSubview:_titleLabel];
    
    _nextImageView = [[UIImageView alloc]initWithFrame:CGRectMake(Width - 20, 16, 10, 20)];
    _nextImageView.image = [UIImage imageNamed:@"find_next"];
    [self.contentView addSubview:_nextImageView];
    
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
