//
//  FindViewController.m
//  TableOptimize
//
//  Created by Yuan on 16/3/18.
//  Copyright © 2016年 Ace. All rights reserved.
//

#import "FindViewController.h"
#import "FindCellModel.h"
@interface FindViewController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation FindViewController

-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.navigationItem.title = @"发现";
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = RGB(240, 240, 240);
    
    UITableView *tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, VW, VH) style:UITableViewStyleGrouped];

    tableView.dataSource = self;
    tableView.delegate = self;
    [self.view addSubview:tableView];
    
}


#pragma mark --- DataSource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    FindCellModel *cellModel = [[FindCellModel alloc]init];
    return [cellModel findnumberOfRowsInSection:section];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    FindCellModel *cellModel = [[FindCellModel alloc]init];
    return [cellModel findtableView:tableView findcellForRowAtIndexPath:indexPath];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 52;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return 10;
            break;
            
        case 1:
            return 5;
            break;
            
        case 2:
            return 5;
            break;
            
        default:
            break;
    }
    return 0;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return 5;
            break;
            
        case 1:
            return 5;
            break;
            
        case 2:
            return 5;
            break;
            
        default:
            break;
    }
    return 0;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
