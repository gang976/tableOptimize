//
//  RequestUrl.m
//  TTD
//
//  Created by Yuan on 15/11/2.
//  Copyright © 2015年 EUC. All rights reserved.
//

#import "RequestUrl.h"

#define BaseUrl @""

@implementation RequestUrl

@end
